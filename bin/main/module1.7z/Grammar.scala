package main

import scala.util.parsing.combinator._
import java.util.Scanner

class Grammar extends JavaTokenParsers {
 
  def statement: Parser[Any] = (admin_statement | ddl_statement | dml_statement| query_statement | transaction_statement)~";"
  def admin_statement: Parser[Any] = exit | print
  def print: Parser[Any] = "(?i)print\\s+dictionary".r | "(?i)print\\s+".r ~ table_name
  def exit: Parser[Any] = "(?i)exit".r ^^ (x=>Exit())
  
  def ddl_statement: Parser[Any] = define_table
  def define_table: Parser[Any] = "(?i)define\\s+table".r ~ table_name ~ "(?i)having\\s+fields".r~"("~extended_field_list~")"
  def dml_statement: Parser[Any] = delete | insert | update
  def delete: Parser[Any] = "(?i)delete\\s+".r ~ table_name ~ opt(where)
  def insert: Parser[Any] = "(?i)insert".r ~ '(' ~ value_list ~ ')'~"(?i)into\\s+".r ~ table_name
  def update: Parser[Any] = "(?i)update\\s+".r ~ table_name ~ "(?i)set\\s+".r ~ field_name ~ "=" ~ value ~ opt(where)
  
  def query_statement: Parser[Any] = selection | projection | join | intersection | union | minus | sort
  def selection: Parser[Any] = "(?i)select\\s+".r ~ query_list ~ opt(where)
  def projection: Parser[Any] = "(?i)project\\s+".r ~ query_list ~ "(?i)over\\s+".r ~ field_list
  def join: Parser[Any] = "(?i)join\\s+".r ~ query_list ~ "(?i)and\\s+".r ~ query_list
  def intersection: Parser[Any] = "(?i)intersect\\s+".r ~ query_list ~ "(?i)and\\s+".r ~ query_list
  def union: Parser[Any] = "(?i)union\\s+".r ~ query_list ~ "(?i)and\\s+".r ~ query_list
  def minus: Parser[Any] = "(?i)minus\\s+".r ~ query_list ~ "(?i)and\\s+".r ~ query_list
  def sort: Parser[Any] = "(?i)order\\s+".r ~ query_list ~ "(?i)by\\s+".r ~ field_name
  def transaction_statement: Parser[Any] = begin | end | pause
  def begin: Parser[Any] = "(?i)begin".r
  def end: Parser[Any] = "(?i)end".r
  def pause: Parser[Any] = "(?i)pause".r ~ "(" ~ integer ~ ")"
  
  def where: Parser[Any] = "(?i)where\\s+".r ~ boolean_expression
  def boolean_expression: Parser[Any] = field_name ~ relop ~ value
  
  def extended_field_list = repsep(field_list, ",\\s+".r)
  def table_name: Parser[Any] = """[a-zA-Z]*""".r
  def query_list: Parser[Any] = query_statement | table_name
  def field_name: Parser[Any] = """[a-zA-Z]*""".r
  def type_ : Parser[Any] = "integer" | "date" | "real" | "varchar" | "boolean"
  def field_list: Parser[Any] = field_name~type_
  
  def value: Parser[Any] = (date | string_expression  | boolean | integer | real)
  def value_list: Parser[Any] = repsep(value, ",\\s+".r)
  def char: Parser[Any] = """[a-zA-Z0-9]""".r
  def integer: Parser[Any] = """[0-9]*""".r
  def real: Parser[Any] = integer~opt('.')~integer | '.'~integer
  def date: Parser[Any] = "'"~d~d~"/"~d~d~"/"~d~d~d~d~"'"
  def d: Parser[Any] = """[0-9]""".r
  def string: Parser[Any] = """[a-zA-Z0-9]*""".r
  def string_expression: Parser[Any] = "\'"~string~"\'"
  def boolean: Parser[Any] = "true" | "false"
  def relop: Parser[Any] = ("=" | "!=" | "<" | ">" | "<=" | ">=")

}

object ParseExpr extends Grammar {
  def parse(s: String) {
	println("input : " + s)
	val p = parseAll(statement, s)
	if(p.successful) println("Valid command.")
	else println("Invalid command.")
	println(p)
  }
}

object Main extends App {
  run
  def run(): Unit = {
    val sc: Scanner = new Scanner(System.in)
    while(true) {
      print('>')
      var in = sc.nextLine()
      while(!in.contains(';'))
        in=in.concat(" " + sc.nextLine())
      ParseExpr.parse(in)
    }
  }
}