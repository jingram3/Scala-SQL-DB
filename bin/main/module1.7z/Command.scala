package main

class Command {
  
      
}

  case class Statement(c: Command) extends Command
  case class Admin_Statement(c: Command) extends Command
  case class Print(c: Command) extends Command
  case class Exit() extends Command {
    println("Exiting.")
    System.exit(0)
  }
  case class DDL_Statement(c: Command) extends Command
  case class Define_Table(c: Command) extends Command
